# Ralph Loop Readiness Checklist

- `CLAUDE.md` or equivalent brief exists.
- `backlog.md` exists and is actionable.
- `progress.md` exists and is compact.
- one validation command is documented.
- loop mode is chosen: single-agent, dual failover, or team-parallel.
- single-writer locking strategy is defined.
- generated loop state is kept outside canonical docs.
