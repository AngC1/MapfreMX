# New Repo Bootstrap Checklist

- Decide the canonical document hierarchy before adding many docs.
- Create `README.md`, constitution, ADR index, contracts, eval strategy, `backlog.md`, and `progress.md`.
- Publish shared agent rules before tool-specific adapters.
- Add at least one validation entrypoint.
- Distinguish canonical docs from operational files in writing.
- Decide whether Ralph loops are in scope and what the default mode is.
