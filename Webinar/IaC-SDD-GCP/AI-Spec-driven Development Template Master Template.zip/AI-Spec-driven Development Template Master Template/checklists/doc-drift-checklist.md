# Doc Drift Checklist

- Does any operational file claim a path or asset that does not exist?
- Does any canonical doc still describe old boundaries?
- Do prompts and skills still match the current operating model?
- Are deprecated docs marked clearly?
- Are examples still examples, not accidental standards?
