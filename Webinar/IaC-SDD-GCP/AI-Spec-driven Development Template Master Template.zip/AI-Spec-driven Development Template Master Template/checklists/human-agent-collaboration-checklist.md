# Human-Agent Collaboration Checklist

- Is the authority model explicit?
- Can a human see what the next safe task is quickly?
- Can an agent distinguish facts from assumptions?
- Are handoffs compact and current?
- Are prompts and skills reusable instead of thread-local?
- Are blockers recorded instead of hidden in chat history?
