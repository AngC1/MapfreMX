# Contract Change Checklist

- Identify every boundary affected.
- Update contract docs and fixtures.
- Update error mappings if needed.
- Update compatibility notes or versioning rules.
- Run contract tests and relevant integration tests.
- Verify clients or downstream consumers remain safe.
