# Task Execution Checklist

- Read the governing canonical docs first.
- Confirm the smallest unlocked task.
- State the owning module, outputs, tests, and likely files.
- Implement the smallest safe slice.
- Run relevant validation.
- Update operational state if status changed.
- Check whether docs changed at the boundary.
