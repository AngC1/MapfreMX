# Framework Map

This file is the structural index for the master template.

## Top-Level Guides

- [00-START-HERE.md](00-START-HERE.md): entry point
- [01-current-repo-audit.md](01-current-repo-audit.md): audit of this repository
- [03-agent-consumption-order.md](03-agent-consumption-order.md): how agents should read and follow the system
- [04-recommended-folder-structure.md](04-recommended-folder-structure.md): portable repo layout
- [05-adoption-guide.md](05-adoption-guide.md): how to adapt this framework to a new repo

## Governance

- [governance/README.md](governance/README.md)
- [governance/canonical-vs-operational.md](governance/canonical-vs-operational.md)
- [governance/document-frontmatter-standard.md](governance/document-frontmatter-standard.md)
- [governance/document-hierarchy-and-precedence-template.md](governance/document-hierarchy-and-precedence-template.md)
- [governance/extension-and-deprecation-policy.md](governance/extension-and-deprecation-policy.md)
- [governance/documentation-chaos-prevention.md](governance/documentation-chaos-prevention.md)

## Templates

- `templates/core/`: repo basics, constitution, onboarding, glossary, definition of done
- `templates/architecture/`: ADRs, specs, module boundaries, state models, architecture reviews
- `templates/contracts/`: APIs, DTOs, events, errors, versioning, contract test matrix
- `templates/quality/`: evals, degraded behavior, budgets, observability, release readiness
- `templates/execution/`: backlog, progress, handoffs, validation reports, operational tracking
- `templates/agent-control/`: shared agent rules plus tool-specific adapters

## Workflow Library

- [workflow-library/ralph-loops/README.md](workflow-library/ralph-loops/README.md)

## Prompt Library

- `prompt-library/engineering/`: execution and review prompts
- `prompt-library/ux/`: UX, accessibility, and state-quality prompts
- `prompt-library/architecture/`: architecture analysis prompts
- `prompt-library/documentation/`: onboarding and reconciliation prompts

## Skills Library

- [skills-library/README.md](skills-library/README.md)
- [skills-library/skill-packaging-guide.md](skills-library/skill-packaging-guide.md)
- `skills-library/skill-template/`: starter assets
- `skills-library/examples/`: reusable example skills

## Checklists and Examples

- `checklists/`: repeatable execution and governance checklists
- `examples/`: sample mappings for different repository types

## Intended Use

Use this map in two ways:
- as an onboarding table of contents for a new repo
- as a completeness checklist when copying the framework into an existing repo
