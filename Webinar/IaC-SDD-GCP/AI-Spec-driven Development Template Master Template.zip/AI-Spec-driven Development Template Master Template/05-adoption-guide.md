# Adoption Guide

This guide explains how to adapt the framework to a new repository without creating documentation noise.

## Step 1: Decide The Operating Depth

Choose one of these starting points:
- Minimal: README, constitution, ADR index, contracts, eval strategy, backlog, progress, shared agent rules
- Standard: minimal set plus module specs, quality docs, prompt library, and loop workflow docs
- Full: standard set plus skills library, examples, anti-drift checks, and team-specific commands

## Step 2: Establish Canonical Authority

- Copy the governance docs first.
- Decide which documents are canonical in the host repo.
- Publish a document hierarchy before adding many templates.

## Step 3: Fit The Templates To The Repo

- Keep the placeholder style `{{placeholder_name}}`.
- Replace only the repository-specific values.
- Do not copy templates that the repo will not actively use.

## Step 4: Publish Shared Agent Rules Before Tool Adapters

- Start with `templates/agent-control/shared-agent-rules-template.md`.
- Then derive `AGENTS.md`, `CLAUDE.md`, and any Cursor or tool-specific rule files.
- Keep shared policy in one place. Tool-specific files should be wrappers, not alternate constitutions.

## Step 5: Separate Canonical Planning From Live Execution

- Keep long-lived roadmap or sequencing docs under `docs/planning/`.
- Keep live execution state in `backlog.md`, `progress.md`, and session handoffs.
- Do not merge those layers unless the repo is intentionally tiny.

## Step 6: Add Validation Early

- Add at least one docs-drift check.
- Add link validation for Markdown docs.
- Add one architecture compliance check if the repo has meaningful layering.

## Step 7: Review After First Real Sprint

After one real implementation cycle:
- remove unused templates
- collapse duplicate guidance
- clarify any authority confusion
- promote repeated prompts or skills into shared assets

## Adoption Principle

The framework should make the repo easier to execute. If a document does not improve execution, safety, or clarity, do not keep it.
