# AI Spec-driven Development Template Master Template

La forma correcta de usarla esta plantilla es como un sistema operativo documental, no como una carpeta de Markdown para “copiar todo” sin criterio.

Empieza por estos archivos, en este orden:
1. [00-START-HERE.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/00-START-HERE.md>)
2. [02-framework-map.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/02-framework-map.md>)
3. [03-agent-consumption-order.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/03-agent-consumption-order.md>)
4. [04-recommended-folder-structure.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/04-recommended-folder-structure.md>)
5. [05-adoption-guide.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/05-adoption-guide.md>)

Si la quieres entender en el contexto de este repo, lee también [01-current-repo-audit.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/01-current-repo-audit.md>), porque ahí está qué se rescató del repo actual, qué está incompleto y qué está redundante.

**Cómo usarla en un repo nuevo**
1. Define primero la autoridad documental.
   Usa [governance/canonical-vs-operational.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/governance/canonical-vs-operational.md>) y [governance/document-hierarchy-and-precedence-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/governance/document-hierarchy-and-precedence-template.md>) para dejar claro qué documentos son canónicos y cuáles son operativos.
2. Crea el set mínimo.
   Normalmente basta con:
   - `README.md`
   - constitución
   - índice ADR
   - contratos
   - estrategia de evaluación
   - `backlog.md`
   - `progress.md`
3. Rellena los templates base.
   Empieza por:
   - [templates/core/repository-readme-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/core/repository-readme-template.md>)
   - [templates/core/constitution-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/core/constitution-template.md>)
   - [templates/core/doc-inventory-and-reconciliation-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/core/doc-inventory-and-reconciliation-template.md>)
4. Luego define arquitectura y límites.
   Usa:
   - [templates/architecture/adr-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/architecture/adr-template.md>)
   - [templates/architecture/module-tds-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/architecture/module-tds-template.md>)
   - [templates/architecture/dependency-boundary-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/architecture/dependency-boundary-template.md>)
5. Después define fronteras públicas.
   Usa:
   - [templates/contracts/api-contract-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/contracts/api-contract-template.md>)
   - [templates/contracts/dto-schema-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/contracts/dto-schema-template.md>)
   - [templates/contracts/error-normalization-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/contracts/error-normalization-template.md>)
   - [templates/contracts/event-schema-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/contracts/event-schema-template.md>)
6. Luego añade calidad y validación.
   Empieza por:
   - [templates/quality/eval-strategy-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/quality/eval-strategy-template.md>)
   - [templates/quality/failure-modes-and-degraded-behavior-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/quality/failure-modes-and-degraded-behavior-template.md>)
   - [templates/quality/latency-budget-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/quality/latency-budget-template.md>)
7. Por último, activa la operación diaria.
   Usa:
   - [templates/execution/backlog-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/execution/backlog-template.md>)
   - [templates/execution/progress-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/execution/progress-template.md>)
   - [templates/execution/session-handoff-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/execution/session-handoff-template.md>)

**Cómo usarla con agentes**
La clave está en no duplicar reglas por herramienta. Primero defines una sola fuente compartida en [templates/agent-control/shared-agent-rules-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/agent-control/shared-agent-rules-template.md>) y luego generas adaptadores finos:
- [templates/agent-control/AGENTS-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/agent-control/AGENTS-template.md>)
- [templates/agent-control/CLAUDE-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/agent-control/CLAUDE-template.md>)
- [templates/agent-control/cursor-rules-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/templates/agent-control/cursor-rules-template.md>)

Eso evita tener tres “constituciones” distintas para Codex, Claude y Cursor.

**Cómo usarla con Ralph loops**
Si quieres automatización iterativa, usa la librería de workflows en [workflow-library/ralph-loops/README.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/workflow-library/ralph-loops/README.md>). El orden recomendado es:
1. [operating-model.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/workflow-library/ralph-loops/operating-model.md>)
2. [single-agent-loop.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/workflow-library/ralph-loops/single-agent-loop.md>)
3. [team-parallel-advisor-executor.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/workflow-library/ralph-loops/team-parallel-advisor-executor.md>)
4. [single-writer-safety.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/workflow-library/ralph-loops/single-writer-safety.md>)
5. [loop-prompt-template.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/workflow-library/ralph-loops/loop-prompt-template.md>)
6. [repo-adaptation-for-ralph-loops.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/workflow-library/ralph-loops/repo-adaptation-for-ralph-loops.md>)

La idea es simple:
- `backlog.md` define qué sigue
- `progress.md` deja el handoff compacto
- `CLAUDE.md` o equivalente define el brief operativo
- el loop procesa una tarea pequeña por iteración
- un solo writer toca esos archivos compartidos

**Cómo usar prompts y skills**
La carpeta `prompt-library/` es para tareas repetibles de alto nivel. Por ejemplo:
- ingeniería: ejecución, review, PR writing
- arquitectura: auditorías de límites
- documentación: onboarding y reconciliación
- UX: auditorías de estados y accesibilidad

La carpeta `skills-library/` es para empaquetar workflows reutilizables. El punto de partida es:
- [skills-library/skill-template/SKILL.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/skills-library/skill-template/SKILL.md>)
- [skills-library/skill-packaging-guide.md](</Users/christian/shared/proyectos/conversation-os-ai/AI-Spec-driven Development Template Master Template/skills-library/skill-packaging-guide.md>)

Regla práctica:
- `prompt-library` = instrucciones reutilizables para ejecutar una tarea
- `skills-library` = capacidad reusable con estructura, guardrails y opcionalmente referencias/scripts

**Qué no debes hacer**
- No copies toda la template si el repo no la necesita.
- No conviertas `backlog.md` y `progress.md` en documentos canónicos.
- No dupliques reglas entre `AGENTS.md`, `CLAUDE.md` y Cursor.
- No metas artifacts de loops o logs dentro de `docs/`.
- No dejes placeholders `{{...}}` mezclados con contenido real sin decisión.

**Forma recomendada de adoptarla**
Si quieres usarla bien, hazlo en tres fases:
1. Base: governance + core + execution + agent-control.
2. Rigor: architecture + contracts + quality.
3. Escala: workflow-library + prompt-library + skills-library + checklists.

Si quieres, el siguiente paso útil es que yo te la adapte a un caso concreto. Por ejemplo:
- convertir esta template en un `ai-specs/` real para este repo
- usarla para scaffold de un repo nuevo
- o mapear exactamente qué carpetas de esta template deberías promover desde `manual-SDD-main/` y cuáles dejar como referencia.