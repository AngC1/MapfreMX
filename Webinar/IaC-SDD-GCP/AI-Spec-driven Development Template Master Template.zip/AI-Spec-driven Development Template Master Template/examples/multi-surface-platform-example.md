# Example: Multi-Surface Platform Repository

This is the fuller mapping for a repository with multiple clients, a shared backend, explicit contracts, and long-lived architecture decisions.

## Recommended Set

- constitution
- cross-cutting ADRs plus specialized ADR packs where needed
- module-oriented specs
- contract suite for APIs, DTOs, events, and errors
- reliability and performance docs
- eval strategy
- live `backlog.md` and `progress.md`
- shared agent-control layer with thin tool adapters
- Ralph-loop workflow docs if automated execution loops are used

## Example Pattern

The current Conversation OS repository shows a strong version of this architecture-heavy model. Use it as an example of rigor, not as a default product shape for every new repo.
