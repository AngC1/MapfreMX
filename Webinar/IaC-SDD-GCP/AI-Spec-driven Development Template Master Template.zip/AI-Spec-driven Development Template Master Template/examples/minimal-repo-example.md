# Example: Minimal Repository

Use this mapping for a small repository that still wants disciplined execution.

## Recommended Set

- `README.md`
- constitution
- one ADR index
- one contracts folder
- eval strategy
- `backlog.md`
- `progress.md`
- shared agent rules

## Skip At First

- large specialized ADR packs
- deep prompt library
- advanced multi-provider loop orchestration

## Why

Small repositories still benefit from explicit authority and tracking, but they do not need maximal document volume on day one.
