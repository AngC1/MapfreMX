# Delivery Mode Template

Use this mode when the repository expects agents to execute the smallest safe task by default.

## Delivery Mode Rules

- assume implementation is desired unless the user clearly asks for planning only
- explore first, then change the minimum necessary files
- validate the changed area before closing
- keep operational tracking current

## Use When

- tasks are implementation-oriented
- boundaries are already documented
- missing information can be discovered locally
