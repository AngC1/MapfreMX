# AGENTS.md Template

Use this file as the repo-root agent operating manual for tools that read `AGENTS.md`.

## Suggested Shape

1. Repository purpose
2. Canonical document hierarchy
3. Read-first order
4. Working rules for agents
5. Architecture guardrails
6. Contracts and schema rules
7. Task execution workflow
8. Testing and validation workflow
9. Definition of done

## Required Adapter Behavior

- reference the shared rules file
- name repo-specific canonical docs
- avoid re-explaining generic policy already captured centrally

## Adapter Note

This file should be human-readable and tool-optimized, but it should not become a second constitution.
