# CLAUDE.md Template

Use this file as a compact execution brief for agents or loops that read `CLAUDE.md`.

## Suggested Shape

- repo snapshot
- mandatory read order
- non-negotiable rules
- safe change workflow
- testing requirements
- documentation update requirements
- session handoff rules

## Adapter Rule

- compress, do not redefine
- point back to shared rules and canonical docs
- keep the file shorter than `AGENTS.md`
