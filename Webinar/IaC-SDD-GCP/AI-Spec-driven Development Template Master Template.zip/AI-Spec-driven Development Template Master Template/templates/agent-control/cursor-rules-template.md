# Cursor Rules Template

Use this template when adapting the shared rules to Cursor or a similar editor-specific rule system.

## Design Rules

- keep the file short
- point to shared rules and canonical docs
- avoid embedding repo-specific architectural detail twice
- make execution defaults explicit

## Recommended Sections

- scope of the rule file
- required reading order
- do and do not rules
- note on canonical vs operational docs

## Anti-Pattern

Do not paste the full constitution into editor rules. Use editor rules as an adapter, not as the root policy source.
