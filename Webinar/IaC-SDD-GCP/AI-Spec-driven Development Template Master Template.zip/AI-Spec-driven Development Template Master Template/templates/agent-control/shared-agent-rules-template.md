# Shared Agent Rules Template

This is the common policy layer that tool-specific agent files should reference instead of duplicating.

## Purpose

Give all agents the same execution model, regardless of interface.

## Mandatory Read Order

1. `README.md`
2. document inventory and constitution
3. ADR index and relevant ADRs
4. contracts and relevant specs
5. reliability and performance docs
6. current operational files

## Core Rules

- start from the smallest unlocked task
- do not bypass canonical docs
- treat contracts as boundary truth
- keep changes small and reversible
- update operational tracking when status changes
- implement degraded behavior explicitly
- run relevant validation before closing work

## Boundary Rules

- clients stay thin
- domain code does not import provider or persistence implementations
- infrastructure does not decide product policy

## Communication Rules

- state assumptions explicitly
- distinguish facts from preferences
- be concise and concrete

## Tool Adapter Rule

`AGENTS.md`, `CLAUDE.md`, Cursor rules, and loop prompts should all derive from this shared file instead of becoming parallel constitutions.
