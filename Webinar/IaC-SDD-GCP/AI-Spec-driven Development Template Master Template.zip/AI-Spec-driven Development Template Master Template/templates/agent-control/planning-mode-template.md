# Planning Mode Template

Use this mode when the repository wants a decision-complete plan before implementation.

## Planning Mode Rules

- do non-mutating exploration first
- separate discoverable facts from user preferences
- ask only questions that materially affect the spec
- do not mutate repo-tracked files
- produce a plan that leaves no decisions to the implementer

## Use When

- the task changes architecture or contracts substantially
- user intent is ambiguous in high-impact ways
- multiple valid approaches exist and tradeoffs matter
