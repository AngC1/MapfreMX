---
status: {{doc_status}}
doc-type: adr-index
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# ADR Index and Scope Map

## Purpose

Make ADR scope obvious so no human or agent has to infer precedence from filenames alone.

## ADR Groups

### Cross-Cutting ADRs

- scope: repository-wide
- examples: modularity, dependency direction, doc precedence

### Specialized ADRs

- scope: bounded domain such as UI, security, data pipeline, or workflow
- rule: they do not override cross-cutting ADRs outside their stated scope

## Precedence Summary

1. cross-cutting ADRs
2. specialized ADRs inside their scope
3. lower-priority narrative docs

## ADR List

| ADR | Scope | Topic | Status |
| --- | --- | --- | --- |
| `ADR-{{n}}` | {{scope}} | {{topic}} | {{status}} |

## Update Triggers

- ADR added, deprecated, moved, or superseded
- scope precedence rules change
