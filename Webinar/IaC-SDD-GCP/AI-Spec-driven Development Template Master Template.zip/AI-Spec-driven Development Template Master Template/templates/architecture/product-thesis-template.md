---
status: {{doc_status}}
doc-type: product-spec
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Product Thesis

## Purpose

Define what the product is, who it serves, and what it must not drift into.

## Target Users

- primary: {{primary_user}}
- secondary: {{secondary_user}}

## Core Jobs

- {{job_to_be_done_1}}
- {{job_to_be_done_2}}

## Product Principles

- {{principle_1}}
- {{principle_2}}
- {{principle_3}}

## Non-Goals

- {{non_goal_1}}
- {{non_goal_2}}

## Delivery Implications

- {{delivery_implication_1}}
- {{delivery_implication_2}}

## Update Triggers

- target users change materially
- product principles or non-goals change
- architecture or workflow assumptions are affected by product scope changes
