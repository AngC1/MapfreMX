---
status: {{doc_status}}
doc-type: spec
authority: canonical
scope: {{doc_scope}}
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# State Model: {{system_or_feature_name}}

## Purpose

Define the explicit states, transitions, and invalid transitions for a feature or subsystem.

## States

| State | Meaning | User-visible? |
| --- | --- | --- |
| `{{state_1}}` | {{meaning_1}} | {{yes_or_no}} |
| `{{state_2}}` | {{meaning_2}} | {{yes_or_no}} |

## Transitions

| From | To | Trigger | Notes |
| --- | --- | --- | --- |
| `{{from_state}}` | `{{to_state}}` | {{trigger}} | {{notes}} |

## Invalid Transitions

- `{{invalid_transition_1}}`: {{reason}}

## Failure and Recovery

- degraded state: {{degraded_state_rule}}
- recovery path: {{recovery_rule}}
- observability: {{event_or_log_rule}}

## Update Triggers

- new state introduced
- transition semantics change
- degraded or recovery behavior changes
