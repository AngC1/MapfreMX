---
status: {{doc_status}}
doc-type: adr
authority: canonical
scope: {{doc_scope}}
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# ADR-{{adr_number}}: {{decision_title}}

## Status

{{accepted_or_other_status}}

## Context

- {{context_fact_1}}
- {{context_fact_2}}
- {{constraint_1}}

## Decision

{{decision_statement}}

## Why

- {{reason_1}}
- {{reason_2}}

## Consequences

### Positive

- {{positive_1}}

### Negative

- {{negative_1}}

## Rejected Alternatives

- `{{alternative_1}}`: {{why_rejected_1}}
- `{{alternative_2}}`: {{why_rejected_2}}

## Implementation Notes

- affected modules: {{modules}}
- contract impact: {{contract_impact}}
- update triggers: {{docs_or_tests_to_update}}

## Update Triggers

- change in repository-wide policy
- new dependency direction
- boundary or contract change caused by this decision
