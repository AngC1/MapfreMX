---
status: {{doc_status}}
doc-type: spec
authority: canonical
scope: module
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# TDS: {{module_name}}

## Purpose

{{module_purpose}}

## Scope

Includes:
- {{in_scope_1}}
- {{in_scope_2}}

Excludes:
- {{out_of_scope_1}}
- {{out_of_scope_2}}

## Ownership

- owns: {{owned_capabilities}}
- does not own: {{not_owned_capabilities}}

## Dependencies

- may depend on: {{allowed_dependencies}}
- must not depend on: {{forbidden_dependencies}}

## Interfaces

- inputs: {{accepted_inputs}}
- outputs: {{emitted_outputs}}
- normalized errors: {{normalized_errors}}

## State, Async, and Observability

- state model: {{state_model_summary}}
- async rules: {{async_summary}}
- observability hooks: {{observability_summary}}

## Acceptance and Tests

- acceptance criteria: {{acceptance_summary}}
- required tests: {{test_summary}}

## Update Triggers

- ownership changes
- allowed or forbidden dependencies change
- emitted outputs, inputs, or normalized errors change
