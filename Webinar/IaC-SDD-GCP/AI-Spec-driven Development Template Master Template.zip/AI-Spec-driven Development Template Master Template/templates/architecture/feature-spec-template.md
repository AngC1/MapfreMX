---
status: {{doc_status}}
doc-type: feature-spec
authority: canonical
scope: feature
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Feature Spec: {{feature_name}}

## Outcome

{{feature_outcome_summary}}

## Users and Trigger

- user: {{target_user}}
- trigger: {{entry_condition}}

## In Scope

- {{in_scope_1}}
- {{in_scope_2}}

## Out Of Scope

- {{out_of_scope_1}}
- {{out_of_scope_2}}

## Key Flows

1. {{flow_step_1}}
2. {{flow_step_2}}
3. {{flow_step_3}}

## State and Failure Modes

- expected states: {{states}}
- degraded behavior: {{degraded_behavior}}
- hard failure: {{hard_failure_behavior}}

## Boundary Impact

- contracts touched: {{contracts}}
- modules touched: {{modules}}
- tests required: {{tests}}
- docs to update: {{docs_to_update}}

## Update Triggers

- user flow changes
- state model changes
- public boundary or degraded behavior changes
