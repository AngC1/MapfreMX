---
status: {{doc_status}}
doc-type: review
authority: canonical
scope: {{doc_scope}}
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Architecture Review: {{review_subject}}

## Review Question

{{review_question}}

## Current Shape

- modules involved: {{modules}}
- boundaries involved: {{boundaries}}
- assumptions: {{assumptions}}

## Findings

| Severity | Finding | Why It Matters | Recommended Action |
| --- | --- | --- | --- |
| {{severity}} | {{finding}} | {{impact}} | {{action}} |

## Risks If Unchanged

- {{risk_1}}
- {{risk_2}}

## Recommended Follow-Up

- doc changes: {{doc_changes}}
- test changes: {{test_changes}}
- implementation changes: {{implementation_changes}}

## Update Triggers

- review is rerun after major architecture change
- findings result in accepted boundary or ownership changes
