---
status: {{doc_status}}
doc-type: spec
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Dependency Boundary Rules

## Purpose

Define allowed dependency directions and forbidden imports across the repository.

## Primary Layers

1. {{layer_1}}
2. {{layer_2}}
3. {{layer_3}}
4. {{layer_4}}

## Allowed Direction

`{{higher_layer}} -> {{lower_layer_or_contract}}`

## Forbidden Direction

- `{{forbidden_direction_1}}`
- `{{forbidden_direction_2}}`

## Boundary Enforcement

- code review rule: {{review_rule}}
- automated check: {{automation_rule}}
- temporary allowlist policy: {{allowlist_policy}}

## Examples

- allowed: {{allowed_example}}
- forbidden: {{forbidden_example}}

## Update Triggers

- new layer introduced
- import boundary automation changes
- allowlist policy changes
