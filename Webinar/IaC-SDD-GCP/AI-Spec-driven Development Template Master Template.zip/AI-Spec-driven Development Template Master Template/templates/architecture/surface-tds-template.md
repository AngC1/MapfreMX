---
status: {{doc_status}}
doc-type: spec
authority: canonical
scope: surface
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Surface TDS: {{surface_name}}

## Purpose

Describe how a concrete surface delivers behavior using underlying platform modules.

## Scope

- surface type: {{surface_type}}
- target user: {{target_user}}

## Consumed Boundaries

- contracts used: {{contracts}}
- upstream modules: {{upstream_modules}}

## Surface Responsibilities

- {{responsibility_1}}
- {{responsibility_2}}

## Surface Must Not Do

- {{forbidden_behavior_1}}
- {{forbidden_behavior_2}}

## State Model

- loading
- loaded
- empty
- degraded
- error
- {{additional_state_if_needed}}

## Delivery Notes

- rendering or interaction rules: {{delivery_notes}}
- accessibility or platform rules: {{a11y_notes}}
- tests: {{test_summary}}

## Update Triggers

- user-visible states change
- consumed contracts change
- surface-specific constraints or platform behavior change
