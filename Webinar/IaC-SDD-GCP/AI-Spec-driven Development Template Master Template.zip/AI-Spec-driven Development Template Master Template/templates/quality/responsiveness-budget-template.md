---
status: {{doc_status}}
doc-type: quality-policy
authority: canonical
scope: surface
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Responsiveness Budget

## Purpose

Define interaction-level responsiveness expectations for user-facing surfaces.

## Targets

- visible response to direct interaction: {{interaction_target}}
- initial loading indication: {{loading_indicator_target}}
- first meaningful streaming output: {{streaming_target}}

## Rules

- do not hide slow work behind inert spinners
- if work cannot complete quickly, surface progress or partial readiness
- degraded states must appear faster than total uncertainty
