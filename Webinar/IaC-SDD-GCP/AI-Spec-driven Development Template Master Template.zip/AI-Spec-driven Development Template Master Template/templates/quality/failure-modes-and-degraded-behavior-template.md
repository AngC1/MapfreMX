---
status: {{doc_status}}
doc-type: quality-policy
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Failure Modes and Degraded Behavior

## Core Principle

A dependency failure should not collapse unrelated useful behavior when a safer degraded mode exists.

## Failure Matrix

| Failure Mode | Affected Capability | Required Behavior |
| --- | --- | --- |
| {{failure_1}} | {{capability_1}} | {{behavior_1}} |
| {{failure_2}} | {{capability_2}} | {{behavior_2}} |

## Required Degraded States

- catalog-only or read-only mode where relevant
- partial readiness state where background work is incomplete
- explicit disconnected state when backend or transport is down
- no-evidence state when retrieval-required flows lack support

## Recovery Expectations

- bounded retry policy
- explicit rebuild or replay path if applicable
- observable recovery transition
