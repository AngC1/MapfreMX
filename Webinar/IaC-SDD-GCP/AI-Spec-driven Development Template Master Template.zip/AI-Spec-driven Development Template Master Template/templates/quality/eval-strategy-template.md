---
status: {{doc_status}}
doc-type: quality-policy
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Eval Strategy

## Purpose

Define the evidence required before work is accepted.

## Test Layers

- unit tests for domain logic
- integration tests for adapters and persistence
- contract tests for DTOs, events, and errors
- end-to-end tests for primary flows
- degraded-mode tests for failure cases
- architecture compliance checks where boundaries matter

## Acceptance Thresholds

1. contract tests pass
2. no critical boundary violations
3. degraded behavior is covered
4. performance budgets pass or exceptions are documented
5. docs are current when behavior changed

## Required Evidence Before Merge

- tests added or updated
- validation summary
- degraded behavior note
- docs updated note
