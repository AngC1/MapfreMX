---
status: {{doc_status}}
doc-type: quality-policy
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Observability Requirements

## Purpose

Define the minimum signals required for side-effecting or failure-prone flows.

## Required Signals

- structured logs with correlation IDs
- lifecycle events for long-running work
- normalized error events
- timing data for critical paths
- degraded-mode entry and exit markers

## Logging Rules

- never log secrets
- never log full sensitive content by default
- redact debug output intentionally

## Review Trigger

If a new background job, adapter, or workflow is introduced, update this document or confirm the existing rules still cover it.
