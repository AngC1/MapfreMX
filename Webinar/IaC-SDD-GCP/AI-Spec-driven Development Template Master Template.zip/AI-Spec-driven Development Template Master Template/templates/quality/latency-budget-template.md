---
status: {{doc_status}}
doc-type: quality-policy
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Latency Budget

## Reference Environment

{{reference_environment}}

## Target Budgets

| Flow | Median | P95 | Notes |
| --- | --- | --- | --- |
| {{flow_1}} | {{median_1}} | {{p95_1}} | {{notes_1}} |
| {{flow_2}} | {{median_2}} | {{p95_2}} | {{notes_2}} |

## Rules

- budgets are targets, not excuses to hide correctness problems
- when budgets are missed, document where and why
- do not silently lower budgets without review
