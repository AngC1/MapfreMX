---
status: {{doc_status}}
doc-type: quality-policy
authority: canonical
scope: release
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Release Readiness

## Release Candidate Summary

- scope: {{release_scope}}
- boundary changes: {{boundary_changes}}
- risky areas: {{risk_summary}}

## Required Checks

- tests pass
- contract changes reviewed
- degraded behavior verified
- rollback path documented
- operational runbooks updated if affected

## Sign-Off

| Role | Required | Status |
| --- | --- | --- |
| engineering | yes | {{status}} |
| product | {{yes_or_no}} | {{status}} |
| operations | {{yes_or_no}} | {{status}} |
