# Task Brief Template

Operational document. Non-canonical.

## Task

{{task_name}}

## Goal

{{goal}}

## Boundaries

- owning layer or module: {{owner}}
- contracts involved: {{contracts}}
- likely files: {{files}}
- non-goals: {{non_goals}}

## Acceptance

- {{acceptance_1}}
- {{acceptance_2}}

## Required Validation

- {{validation_1}}
- {{validation_2}}

## Assumptions

- {{assumption_1}}
