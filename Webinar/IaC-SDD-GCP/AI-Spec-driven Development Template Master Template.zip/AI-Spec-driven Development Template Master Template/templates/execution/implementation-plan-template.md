# Implementation Plan Template

Operational document. Non-canonical.

## Summary

{{summary}}

## Key Changes

- {{change_1}}
- {{change_2}}

## Boundary Impact

- public interfaces: {{interfaces}}
- migrations or compatibility: {{compatibility_notes}}

## Test Plan

- {{test_1}}
- {{test_2}}

## Assumptions

- {{assumption_1}}
