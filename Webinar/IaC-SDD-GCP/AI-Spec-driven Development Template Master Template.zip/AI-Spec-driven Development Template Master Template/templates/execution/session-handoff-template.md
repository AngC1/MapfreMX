# Session Handoff Template

Operational document. Non-canonical.

## What Changed

- {{change_1}}

## What Remains

- {{remaining_work}}

## Current Risks

- {{risk_1}}

## Validation Run

- {{validation_summary}}

## Resume From

- read: {{first_file_to_read}}
- next task: {{next_task}}
