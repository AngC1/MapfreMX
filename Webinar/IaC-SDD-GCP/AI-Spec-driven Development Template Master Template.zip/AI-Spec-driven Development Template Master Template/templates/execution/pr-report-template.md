# PR Report Template

Operational document. Non-canonical.

## Title

{{short_title}}

## Summary

{{two_to_three_sentence_summary}}

## What Changed

- {{grouped_change_1}}
- {{grouped_change_2}}

## Validation

- {{validation_1}}
- {{validation_2}}

## Reviewer Notes

- {{where_to_look}}

## Risks

- {{real_risk_or_none}}
