# Validation Report Template

Operational document. Non-canonical.

## Scope

{{scope}}

## Checks Run

| Check | Result | Notes |
| --- | --- | --- |
| {{check_1}} | {{pass_or_fail}} | {{notes_1}} |
| {{check_2}} | {{pass_or_fail}} | {{notes_2}} |

## Gaps

- {{gap_or_none}}

## Recommendation

{{ship_hold_or_follow_up}}
