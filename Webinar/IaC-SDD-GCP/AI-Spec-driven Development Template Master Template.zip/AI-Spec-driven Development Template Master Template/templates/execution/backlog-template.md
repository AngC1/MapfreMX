# Backlog Template

Operational document. Non-canonical.

## Purpose

Track the current execution queue in dependency-aware, actionable order.

## Rules

- keep tasks ordered by unlock status, not wishful priority
- keep acceptance criteria concrete
- avoid long narrative
- point to canonical docs instead of restating them

## Structure

```md
# backlog.md

## Execution Principles
- {{principle_1}}
- {{principle_2}}

## Active Sequence

### Task {{task_number}} - {{task_name}}
**Status:** Planned | In Progress | Done | Blocked
**Depends on:** {{dependency_list}}
**Outputs:** {{outputs}}
**Acceptance:** {{acceptance_summary}}
**Tests:** {{test_summary}}
**Notes:** {{only_if_needed}}
```
