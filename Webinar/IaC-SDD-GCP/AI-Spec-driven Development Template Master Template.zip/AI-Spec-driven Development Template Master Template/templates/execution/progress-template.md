# Progress Template

Operational document. Non-canonical.

## Purpose

Leave a compact current-state handoff for the next human or agent.

## Rules

- keep this file short
- remove stale narrative
- focus on current reality, not full history

## Structure

```md
# progress.md

## Current Status
- phase: {{current_phase}}
- active task: {{active_task}}
- branch: {{branch_name}}

## Last Completed
- {{recent_completion_1}}

## Active Assumptions
- {{assumption_1}}

## Blockers
- {{blocker_or_none}}

## Next Recommended Task
- {{next_task}}

## Validation Snapshot
- {{validation_summary}}
```
