# Risk Register Template

Operational document. Non-canonical.

| Risk | Severity | Likelihood | Mitigation | Owner |
| --- | --- | --- | --- | --- |
| {{risk_1}} | {{severity}} | {{likelihood}} | {{mitigation}} | {{owner}} |

## Use

Keep this register for real active risks only. Move durable policy risks into canonical docs.
