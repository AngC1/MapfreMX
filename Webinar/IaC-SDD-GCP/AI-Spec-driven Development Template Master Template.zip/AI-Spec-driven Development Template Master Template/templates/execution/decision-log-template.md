# Decision Log Template

Operational document. Non-canonical.

| Date | Decision | Why | Follow-Up |
| --- | --- | --- | --- |
| {{yyyy-mm-dd}} | {{decision}} | {{why}} | {{follow_up}} |

## Rule

Use this for working decisions that are too small for ADRs but too important to lose between sessions.
