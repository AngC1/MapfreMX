---
status: {{doc_status}}
doc-type: contract
authority: canonical
scope: boundary
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Event Schema

## Version

`{{event_version}}`

## Common Envelope

```json
{{event_envelope_example}}
```

## Event Type: {{event_type}}

## Required Payload Fields

- `{{payload_field_1}}`
- `{{payload_field_2}}`

## Valid Example

```json
{{valid_event_example}}
```

## Compatibility Rules

- envelope stability: {{envelope_rule}}
- additive payload fields: {{additive_rule}}
- versioning trigger: {{versioning_trigger}}

## Update Triggers

- new event type added
- payload semantics change
- envelope metadata changes
