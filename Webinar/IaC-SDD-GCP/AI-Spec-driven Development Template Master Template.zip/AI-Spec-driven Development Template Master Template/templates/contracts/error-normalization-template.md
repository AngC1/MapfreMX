---
status: {{doc_status}}
doc-type: contract
authority: canonical
scope: boundary
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Error Normalization

## Purpose

Define predictable public errors independent of provider, transport, parser, or storage specifics.

## Error Envelope

```json
{{error_envelope_example}}
```

## Allowed Codes

- `{{code_1}}`
- `{{code_2}}`
- `{{code_3}}`

## Mapping Rules

- parser errors -> {{parser_mapping}}
- validation errors -> {{validation_mapping}}
- dependency errors -> {{dependency_mapping}}
- timeout errors -> {{timeout_mapping}}

## Forbidden Behavior

- raw stack traces in public responses
- provider-native error objects at boundaries
- ambiguous messages without correlation IDs

## Update Triggers

- new normalized code added
- mapping behavior changes
- boundary surfaces change how errors are exposed
