---
status: {{doc_status}}
doc-type: contract
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Contract Test Matrix

| Contract Area | Fixture Source | Positive Test | Negative Test | Compatibility Test |
| --- | --- | --- | --- | --- |
| {{area_1}} | {{fixture_path_1}} | {{positive_1}} | {{negative_1}} | {{compat_1}} |
| {{area_2}} | {{fixture_path_2}} | {{positive_2}} | {{negative_2}} | {{compat_2}} |

## Rules

- every public boundary should map to at least one fixture-backed test
- every breaking change must update this matrix
- degraded responses count as contract behavior and need coverage

## Update Triggers

- new public contract added
- fixture layout changes
- regression coverage gaps are discovered
