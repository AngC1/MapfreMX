---
status: {{doc_status}}
doc-type: contract
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Versioning and Evolution Rules

## Purpose

Keep contract and schema evolution explicit, reviewable, and testable.

## Additive-First Rule

Prefer additive evolution before breaking changes whenever practical.

## Breaking Change Triggers

- removing a field
- changing field meaning
- changing event semantics
- tightening accepted input without migration guidance

## Required For Breaking Changes

- version bump
- migration notes
- contract test updates
- client compatibility review

## Compatibility Promise

{{compatibility_promise}}

## Update Triggers

- versioning policy changes
- compatibility promises change
- migration requirements become stricter or looser
