---
status: {{doc_status}}
doc-type: contract
authority: canonical
scope: boundary
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# API Contracts

## Version

`{{api_version}}`

## Transport Posture

{{transport_summary}}

## Operation: {{operation_name}}

- method: `{{http_method}}`
- path: `{{path}}`
- auth: {{auth_requirements}}

### Request

```json
{{request_example}}
```

### Success Response

```json
{{success_example}}
```

### Failure Behavior

- normalized errors: {{error_codes}}
- degraded behavior: {{degraded_behavior}}

## Compatibility Notes

- additive fields: {{additive_policy}}
- breaking changes: {{breaking_change_policy}}

## Update Triggers

- request or response shape changes
- auth or transport expectations change
- degraded behavior or error mapping changes
