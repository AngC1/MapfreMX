---
status: {{doc_status}}
doc-type: contract
authority: canonical
scope: boundary
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# DTO and Schema Template

## DTO: {{dto_name}}

## Purpose

{{dto_purpose}}

## Fields

| Field | Type | Required | Meaning |
| --- | --- | --- | --- |
| `{{field_1}}` | `{{type_1}}` | {{yes_or_no}} | {{meaning_1}} |
| `{{field_2}}` | `{{type_2}}` | {{yes_or_no}} | {{meaning_2}} |

## Valid Example

```json
{{valid_example}}
```

## Invalid Example

```json
{{invalid_example}}
```

## Evolution Notes

- stable semantics: {{stable_semantics}}
- additive change rules: {{additive_rules}}

## Update Triggers

- field added, removed, or reinterpreted
- validation rules change
- fixture coverage changes
