---
status: {{doc_status}}
doc-type: inventory
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Document Inventory and Reconciliation

## Purpose

Inventory the repository's architecture and workflow documents, classify them, and define the safe source-of-truth hierarchy.

## Source Inventory

| Path | Prior role | Current status | Notes |
| --- | --- | --- | --- |
| `{{path_1}}` | {{prior_role_1}} | {{status_1}} | {{notes_1}} |
| `{{path_2}}` | {{prior_role_2}} | {{status_2}} | {{notes_2}} |

## Contradictions Found

### {{contradiction_name}}

- Conflict: {{conflict_summary}}
- Resolution: {{resolution_summary}}
- Decision strength: {{confirmed_or_assumed}}

## Missing Decisions Added

- {{missing_decision_1}}
- {{missing_decision_2}}

## Normalized Source-Of-Truth Hierarchy

1. {{tier_1}}
2. {{tier_2}}
3. {{tier_3}}

## Open Questions

- {{open_question_1}}
- {{open_question_2}}

## Safe Interpretation Statement

> {{safe_interpretation_statement}}
