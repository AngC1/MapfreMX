---
status: {{doc_status}}
doc-type: glossary
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Glossary

Use this file to stabilize terms that repeatedly affect architecture, contracts, or workflow.

| Term | Meaning | Not This |
| --- | --- | --- |
| `{{term_1}}` | {{meaning_1}} | {{anti_meaning_1}} |
| `{{term_2}}` | {{meaning_2}} | {{anti_meaning_2}} |
| `{{term_3}}` | {{meaning_3}} | {{anti_meaning_3}} |

## Rules

- Define terms that influence implementation decisions.
- Avoid glossary entries for obvious language.
- Update this file when a term starts appearing in ADRs, contracts, and task briefs with inconsistent meaning.
