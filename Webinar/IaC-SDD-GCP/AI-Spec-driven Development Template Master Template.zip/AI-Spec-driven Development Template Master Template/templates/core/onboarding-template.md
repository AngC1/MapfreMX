---
status: {{doc_status}}
doc-type: onboarding
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Onboarding Guide

## Purpose

Get a new human or agent to productive execution with minimal ambiguity.

## First Hour

1. Read `README.md`.
2. Read constitution and ADR index.
3. Read relevant contracts and module specs.
4. Read `backlog.md` and `progress.md`.
5. Run the repo's foundation checks.

## Repository Mental Model

- Product: {{product_summary}}
- Architecture class: {{architecture_class}}
- Primary boundaries: {{boundary_summary}}
- Primary failure modes: {{failure_mode_summary}}

## Required Commands

- `{{foundation_check_command}}`
- `{{test_command}}`
- `{{lint_or_boundary_check_command}}`

## Execution Rules

- start from smallest unlocked task
- do not bypass canonical docs
- record assumptions explicitly
- keep changes small and reversible

## Common Mistakes

- {{mistake_1}}
- {{mistake_2}}

## Where To Ask For Clarification

Use the repo's documented escalation path: {{clarification_path}}
