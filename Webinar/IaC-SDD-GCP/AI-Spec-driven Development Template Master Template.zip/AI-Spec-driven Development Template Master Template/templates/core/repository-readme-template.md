---
status: {{doc_status}}
doc-type: readme
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# {{repo_name}}

## What This Repository Is

{{two_to_four_sentence_summary}}

## Why It Exists

- {{problem_statement}}
- {{target_user_or_team}}
- {{primary_outcome}}

## How To Read This Repo

1. Read `README.md`.
2. Read the document inventory and constitution.
3. Read the ADR index and relevant contracts.
4. Read the current execution files only after canonical docs.

## Canonical Docs

- `docs/architecture/{{inventory_doc}}`
- `docs/constitution/{{constitution_doc}}`
- `docs/adr/{{adr_index_doc}}`
- `docs/contracts/`

## Execution Docs

- `backlog.md`
- `progress.md`
- `docs/planning/`

## Validation Entry Points

- {{foundation_check_command}}
- {{primary_test_command}}
- {{architecture_check_command}}

## Rules Of Thumb

- Keep clients thin.
- Keep contracts explicit.
- Keep degraded behavior observable.
- Prefer small safe changes over broad rewrites.
