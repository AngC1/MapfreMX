---
status: {{doc_status}}
doc-type: quality-policy
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Definition of Done

## A Task Is Done Only When

1. implementation aligns with the constitution and accepted architecture docs
2. contracts are preserved or updated explicitly
3. required tests pass
4. degraded behavior is verified where relevant
5. observability exists for side-effecting paths
6. docs are updated in the same change when behavior changed
7. no forbidden boundary violations were introduced
8. current operational tracking reflects reality

## Required Review Questions

- What changed at the boundary?
- What evidence proves the change is safe?
- What fails differently now?
- Which docs needed updates?
