---
status: {{doc_status}}
doc-type: constitution
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# {{repo_name}} Constitution

## Purpose

Define the engineering law for this repository so humans and agents share one decision model.

## Architecture Goals

1. {{goal_1}}
2. {{goal_2}}
3. {{goal_3}}

## Priority Order

1. correctness
2. user-visible reliability
3. architectural consistency
4. clear ownership boundaries
5. maintainability
6. observability and testability
7. performance within stated budgets

## Layering Rules

- Client layer owns presentation only.
- Application layer owns orchestration and boundary mapping.
- Domain layer owns invariants and business semantics.
- Infrastructure layer owns persistence, transport, and provider adapters.

## Boundary Rules

- Domain modules must not import UI toolkits, persistence drivers, or provider SDKs.
- Clients must not bypass application contracts.
- Raw provider and database errors must not cross public boundaries.

## Required Evidence

- tests appropriate to boundary impact
- degraded-mode behavior where relevant
- observability for side effects
- doc updates when canonical behavior changes

## Forbidden Shortcuts

- {{shortcut_1}}
- {{shortcut_2}}
- {{shortcut_3}}

## Definition Of Done

A task is done only when:
- implementation matches canonical docs
- contracts remain accurate
- tests pass
- operational state is updated
