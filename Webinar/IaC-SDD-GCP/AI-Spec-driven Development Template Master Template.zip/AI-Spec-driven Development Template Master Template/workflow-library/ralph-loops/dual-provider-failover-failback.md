# Dual-Provider Failover and Failback

Use dual-provider orchestration when one provider may become unavailable, rate-limited, or operationally weaker for a period of time.

## Model

- primary provider handles normal execution
- secondary provider takes over when the primary is limited or failing
- the system probes for primary recovery and returns only after a clean pass

## Why This Works

- progress continues under rate limits
- retry logic is centralized
- provider instability does not corrupt task state

## Required Runtime State

- active provider
- loop mode
- retry count
- recovery probe schedule
- last run status

## Anti-Pattern

Do not let both providers write the same execution files concurrently.
