# Team-Parallel Advisor and Executor Mode

This is the preferred pattern when you want model diversity without concurrent writes to the main repo.

## Pattern

1. run two advisors in parallel in isolated workspaces
2. collect both recommendations
3. synthesize one execution prompt
4. run one executor against the main repo

## Benefits

- better idea breadth
- deterministic single-writer execution
- cleaner replay and debugging

## Requirements

- isolated worktrees or copies for advisors
- one executor only
- checkpointed state between phases
- prompt contract that identifies advisor vs executor roles clearly
