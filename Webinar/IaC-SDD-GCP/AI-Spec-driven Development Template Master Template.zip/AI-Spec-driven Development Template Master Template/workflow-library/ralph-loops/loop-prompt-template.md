# Loop Prompt Template

Use this as the base prompt contract for automated execution loops.

```text
Follow {{agent_brief_file}} as the governing workflow.

Read only the minimum relevant context from:
- {{backlog_file}}
- {{progress_file}}

Rules for this pass:
1. Process exactly one smallest unlocked task.
2. Keep scope narrow.
3. Avoid unrelated edits.
4. Run the minimum relevant validation.
5. Update operational state concisely.
6. End with one status marker: CONTINUE, LOOP_STOP, or LOOP_COMPLETE.
```

## Required Qualities

- low ambiguity
- bounded scope
- explicit file references
- explicit completion marker
