# Repo Adaptation for Ralph Loops

Not every repository already has the state files or operating rhythm a Ralph loop expects.

## Minimum Adaptation Steps

1. choose one execution brief file
2. choose one backlog file
3. choose one progress handoff file
4. decide the default validation command
5. define whether the loop is read-write or planning-only

## If The Repo Has No State Files Yet

Start with:
- `CLAUDE.md` or equivalent brief
- `backlog.md`
- `progress.md`

Keep them small. Loops get worse when state files become giant diaries.

## If The Repo Already Has Strong Canonical Docs

Do not copy those docs into loop prompts. Reference them through the execution brief instead.
