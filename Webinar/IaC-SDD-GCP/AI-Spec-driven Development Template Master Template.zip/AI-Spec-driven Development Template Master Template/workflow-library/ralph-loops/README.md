# Ralph Loops Workflow Library

This folder documents a disciplined Ralph-loop operating model for agentic execution.

It is designed for repositories that want:
- repeated small execution passes
- compact state files
- explicit loop prompts
- safe single-writer coordination
- multi-provider collaboration without uncontrolled concurrent writes

## Files

- [operating-model.md](operating-model.md)
- [single-agent-loop.md](single-agent-loop.md)
- [dual-provider-failover-failback.md](dual-provider-failover-failback.md)
- [team-parallel-advisor-executor.md](team-parallel-advisor-executor.md)
- [single-writer-safety.md](single-writer-safety.md)
- [checkpoint-and-state-files.md](checkpoint-and-state-files.md)
- [profile-and-env-conventions.md](profile-and-env-conventions.md)
- [loop-prompt-template.md](loop-prompt-template.md)
- [repo-adaptation-for-ralph-loops.md](repo-adaptation-for-ralph-loops.md)

## Positioning

Treat loop artifacts as operational runtime state. They are useful, but they are not canonical documentation.
