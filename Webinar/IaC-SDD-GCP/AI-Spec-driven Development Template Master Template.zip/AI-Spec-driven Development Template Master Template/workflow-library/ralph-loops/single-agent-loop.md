# Single-Agent Loop

Use a single-agent loop when one model or one tool is enough to make safe incremental progress.

## Best Fit

- smaller repositories
- low concurrency needs
- one clear execution interface

## Required Discipline

- compact task queue
- compact progress handoff
- bounded validation
- clear stop and continue markers

## Iteration Contract

- choose one task
- do not opportunistically broaden scope
- update state files before exit
- leave enough evidence for the next iteration to resume quickly
