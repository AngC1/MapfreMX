# Checkpoint and State Files

## Purpose

Allow loops to resume safely after interruption, rate limiting, or machine restarts.

## Recommended Fields

- loop version
- updated timestamp
- mode
- active provider
- retry count
- pending work summary
- last run outcome
- advisor outputs if team mode is used

## State File Classes

- canonical docs: durable truth
- operational state files: live task and handoff state
- generated runtime files: checkpoints, logs, prompts, raw outputs

Keep those classes separate.
