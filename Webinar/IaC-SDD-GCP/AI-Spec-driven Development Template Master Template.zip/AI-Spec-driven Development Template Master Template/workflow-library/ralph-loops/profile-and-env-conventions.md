# Profile and Environment Conventions

Use profile files to separate runtime configuration from orchestration logic.

## Recommended Variables

- active provider preference
- repo state-file paths
- state root path
- sleep intervals
- probe intervals
- provider CLI binary and model
- rate-limit file paths

## Rules

- keep secret values out of committed profiles
- make file path overrides explicit
- prefer one profile per loop mode

## Naming

- `single-agent.env`
- `dual-auto.env`
- `team-parallel.env`
