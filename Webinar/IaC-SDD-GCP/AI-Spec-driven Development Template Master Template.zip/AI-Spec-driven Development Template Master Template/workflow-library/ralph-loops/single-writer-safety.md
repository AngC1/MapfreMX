# Single-Writer Safety

Shared execution files such as `backlog.md` and `progress.md` should have exactly one active writer at a time.

## Why

- prevents overlapping edits
- protects checkpoint integrity
- keeps task status transitions understandable

## Mechanisms

- lock directory or file with PID ownership
- stale lock timeout
- explicit lock acquisition failure
- checkpoint write after successful iteration

## Canonical Rule

Parallel analysis is fine. Parallel mutation of the same shared state is not.
