# Ralph Loops Operating Model

## Goal

Execute steady, low-ambiguity progress through repeated small passes without losing repository safety.

## Core Pattern

Each loop iteration should:
1. read the governing agent brief
2. read compact operational state
3. pick one smallest unlocked task
4. make one safe change
5. run the minimum relevant validation
6. update operational state

## Principles

- stateless passes, stateful files
- smallest safe unit of work
- single writer for shared execution files
- bounded context load
- explicit stop conditions

## Recommended State Files

- `CLAUDE.md` or equivalent execution brief
- `backlog.md`
- `progress.md`
- optional checkpoint JSON for restart-safe orchestration
