# Agent Consumption Order

This framework assumes agents work better when they do not have to guess authority, scope, or execution order.

## Canonical vs Operational Rule

- Canonical docs define product, architecture, contracts, boundaries, reliability, and performance.
- Operational docs coordinate current execution, handoffs, and loop state.
- Operational files never overrule canonical files.

## Recommended Read Order For Agents

1. Repository `README.md`
2. Document inventory and reconciliation doc
3. Constitution or equivalent engineering law
4. ADR index and top-level cross-cutting ADRs
5. Relevant contracts
6. Relevant module or feature specs
7. Reliability and performance expectations
8. Eval strategy
9. Current operational state: `backlog.md`, `progress.md`, handoff docs
10. Tool-specific agent rules only after the shared rules are understood

## How Agents Should Execute

- Start from the smallest unlocked task.
- Confirm authority before changing behavior.
- Treat contracts as boundary truth.
- Distinguish discovered facts from assumptions.
- Keep changes incremental and reversible.
- Update operational tracking when work status changes unless the repo explicitly opts out.

## How Agents Should Handle Ambiguity

- Resolve what can be discovered locally before asking questions.
- If docs conflict, use the precedence template and record the conflict.
- If no canonical answer exists, state the assumption explicitly and keep the change narrow.

## Ralph-Loop Guidance

In automated loops, agents should:
- read only the minimum relevant context
- avoid broad repository scans on every pass
- preserve single-writer safety for shared execution files
- leave compact, accurate handoffs

See [workflow-library/ralph-loops/operating-model.md](workflow-library/ralph-loops/operating-model.md) for the full loop contract.
