# AI Spec-driven Development Template Master Template

This directory is a reusable operating framework for repositories that want disciplined, agent-friendly, spec-driven execution.

It is designed to do five jobs at once:
- act as a master template for new repositories
- onboard humans and agents into one operating model
- standardize how requirements, architecture, contracts, validation, and delivery are documented
- support Ralph-loop style automation without losing single-writer safety
- reduce ambiguity, drift, and duplicated local conventions

## Start Order

Read these files first:
1. [01-current-repo-audit.md](01-current-repo-audit.md)
2. [02-framework-map.md](02-framework-map.md)
3. [03-agent-consumption-order.md](03-agent-consumption-order.md)
4. [04-recommended-folder-structure.md](04-recommended-folder-structure.md)
5. [05-adoption-guide.md](05-adoption-guide.md)

Then use the supporting libraries:
- [governance/README.md](governance/README.md)
- [templates/core/repository-readme-template.md](templates/core/repository-readme-template.md)
- [templates/architecture/adr-template.md](templates/architecture/adr-template.md)
- [templates/contracts/api-contract-template.md](templates/contracts/api-contract-template.md)
- [templates/quality/eval-strategy-template.md](templates/quality/eval-strategy-template.md)
- [templates/execution/backlog-template.md](templates/execution/backlog-template.md)
- [templates/agent-control/shared-agent-rules-template.md](templates/agent-control/shared-agent-rules-template.md)
- [workflow-library/ralph-loops/README.md](workflow-library/ralph-loops/README.md)
- [skills-library/README.md](skills-library/README.md)

## Design Principles

- Clarity before completeness.
- Canonical docs decide architecture. Operational docs coordinate execution.
- Contracts beat local assumptions at boundaries.
- Smallest safe change beats broad ambition.
- Validation is part of the work, not a follow-up.
- Agents need explicit authority, scope, inputs, outputs, and failure handling.

## Placeholder Convention

All reusable templates use one placeholder style:

```text
{{placeholder_name}}
```

Use that style consistently when adapting templates to a new repository.
