# Current Repository Audit

This audit classifies the current repository's documentation, template, agent-control, and workflow assets into four buckets: useful, incomplete, redundant, and improve next.

## Useful

- `docs/` is the strongest part of the current system.
  - `docs/constitution/ai-repo-constitution.md` sets engineering law clearly.
  - `docs/contracts/` defines boundary truth well, especially API, event, and error normalization.
  - `docs/evals/eval-strategy.md`, `docs/reliability/failure-modes-and-degraded-behavior.md`, and `docs/performance/` establish validation, degraded behavior, and budgets instead of leaving them implicit.
  - `docs/adr/README.md` and `docs/specs/modules/README.md` do real reconciliation work instead of acting as filler indexes.
- `AGENTS.md` is strong as an execution guardrail.
  - It names the canonical hierarchy, read order, boundary rules, and definition of done with low ambiguity.
- `CLAUDE.md` is useful as a compact execution brief.
  - It compresses the same worldview into a faster operational handoff for agent loops.
- `manual-SDD-main/ai-specs` plus `manual-SDD-main/.codex`, `.claude`, and `.cursor` demonstrates a useful pattern:
  - keep shared assets in one place
  - expose thin tool-specific overlays through symlinks
  - avoid rewriting the same skill content for every tool
- `scripts/ralph-loops-v2/` is materially stronger than the older loop bundle.
  - It has a clearer control plane, explicit runtime state, single-writer locking, checkpointing, provider failover/failback, team-parallel advisor/executor mode, and tests.

## Incomplete

- Portable onboarding is still incomplete.
  - `README.md`, `AGENTS.md`, and `CLAUDE.md` are good for this repository, but they do not yet package a generic reusable operating system for other repositories.
- Root operational tracking is useful but under-templated.
  - `backlog.md` and `progress.md` carry a lot of project memory, but the repository does not yet expose a reusable master template for how those files should be structured across repos.
- Prompt and skill assets are not yet promoted into a clearly reusable root framework.
  - The useful patterns are present under `manual-SDD-main/`, but they are not surfaced as the default master template for the repo.
- Ralph loops are operationally meaningful, but there is no standalone documentation pack explaining how to adapt them to a repo that does not already use `CLAUDE.md`, `backlog.md`, and `progress.md`.

## Redundant

- Planning exists in two layers with overlapping intent.
  - `docs/planning/ai-executable-backlog.md` is a canonical planning artifact.
  - `backlog.md` is the live execution queue.
  - Both are useful, but the separation is not template-backed, so a new repo could easily collapse them into one confused document.
- Execution state appears in both `progress.md` and parts of `backlog.md`.
  - The files are serving different jobs, but the boundaries are not enforced by a reusable standard.
- Ralph loop generations coexist.
  - `scripts/ralph-loops/` contains older orchestration patterns.
  - `scripts/ralph-loops-v2/` contains the more disciplined bundle.
  - Without a default recommendation document, a new adopter has to infer which system is preferred.
- Agent-control assets are duplicated by interface.
  - `manual-SDD-main/.codex`, `.claude`, and `.cursor` intentionally mirror the same underlying assets.
  - That duplication is acceptable as an adapter layer, but it should be documented as such rather than read as three separate sources of truth.

## Improve Next

- Fix documentation-reality drift.
  - `progress.md` describes a root `ai-specs/` scaffold and root `.codex/.claude/.cursor` wiring, but those paths are not present in the current working tree.
  - That is exactly the kind of drift a master framework should prevent.
- Make canonical vs operational status unmistakable.
  - The repository has good instincts here, but the distinction needs reusable templates and anti-chaos rules so future repos do not blur authority.
- Publish a reusable folder map and adoption guide.
  - The repository already contains the raw materials for a strong framework, but new adopters would still need to reverse-engineer how the pieces fit together.
- Declare a default Ralph-loop path.
  - The repository should state when to use `scripts/ralph-loops-v2/` and when older scripts are legacy-only.
- Treat generated loop history as operational output, not documentation.
  - `.ralph-loop/`, `.ralph-loop-v2/`, `.ralph-loop-v2-team/`, and `.logs/` are valuable runtime artifacts, but they should never be confused with canonical docs.

## Audit Summary

This repository already has strong architecture, contract, and validation discipline. Its main gap is not rigor. Its main gap is packaging: the useful pieces are not yet consolidated into one portable, low-ambiguity framework for future repositories. This master template is intended to close that gap without rewriting the existing Conversation OS canonical docs in the same pass.
