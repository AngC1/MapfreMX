# Recommended Folder Structure

This is the default portable layout for a spec-driven, agent-friendly repository. Adapt names only when the host repo already has stable conventions.

```text
{{repo_name}}/
├── README.md
├── AGENTS.md
├── CLAUDE.md
├── backlog.md
├── progress.md
├── docs/
│   ├── architecture/
│   ├── constitution/
│   ├── adr/
│   ├── contracts/
│   ├── specs/
│   ├── reliability/
│   ├── performance/
│   ├── evals/
│   ├── planning/
│   └── sources/
├── tests/
├── scripts/
├── .github/workflows/
├── ai-specs/ or .repo-agents/
│   ├── shared-rules/
│   ├── prompts/
│   ├── skills/
│   └── commands/
└── AI-Spec-driven Development Template Master Template/ (optional imported framework copy)
```

## Structure Rules

- Keep canonical docs under `docs/`.
- Keep live operational state near repo root so loops and humans can find it quickly.
- Keep agent assets centralized, then expose thin tool-specific adapters if needed.
- Keep generated loop history and logs outside canonical docs.

## Minimal Required Set

For a new repo, the minimum practical set is:
- `README.md`
- constitution
- ADR index plus at least one cross-cutting ADR
- contracts for public boundaries
- eval strategy
- `backlog.md`
- `progress.md`
- shared agent rules

## Optional But Recommended

- workflow docs for loops
- prompt library
- skills library
- doc drift checklist
- architecture compliance scripts
