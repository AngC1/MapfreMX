---
name: close-requirement
description: Verify whether a requirement is actually complete, including tests, docs, degraded behavior, and operational tracking.
---

# Close Requirement

## Purpose

Prevent work from being declared done on implementation alone.

## Use When

- a task appears complete
- a final verification pass is needed

## Workflow

1. Compare implementation to the requirement and canonical docs.
2. Check tests and validation evidence.
3. Check docs and operational tracking.
4. Declare complete only if all done criteria are satisfied.

## Guardrails

- treat missing validation as incomplete work
- treat stale docs as incomplete work when behavior changed
