---
name: execute-smallest-unlocked-task
description: Execute one safe implementation slice by following the repository's backlog, progress, and canonical document hierarchy.
---

# Execute Smallest Unlocked Task

## Purpose

Move the repository forward in disciplined, low-scope increments.

## Use When

- the repo has a clear backlog
- implementation is desired, not planning only

## Workflow

1. Read governing docs in the required order.
2. Read current operational state.
3. Pick one smallest unlocked task.
4. Implement the smallest safe slice.
5. Run relevant validation.
6. Update operational tracking.

## Guardrails

- do not span multiple tasks
- do not bypass contracts
- keep changes reversible
