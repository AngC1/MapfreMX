---
name: repo-doc-audit
description: Audit repository documentation, agent-control files, and workflow docs for usefulness, gaps, redundancy, and drift.
---

# Repo Doc Audit

## Purpose

Assess whether the repository's documentation system is coherent and execution-safe.

## Workflow

1. Inventory the docs and operating files.
2. Classify useful, incomplete, redundant, and improve-next areas.
3. Tie findings to concrete files.
4. Recommend consolidation or stronger authority boundaries where needed.

## Guardrails

- distinguish canonical docs from operational files
- do not treat generated artifacts as documentation
