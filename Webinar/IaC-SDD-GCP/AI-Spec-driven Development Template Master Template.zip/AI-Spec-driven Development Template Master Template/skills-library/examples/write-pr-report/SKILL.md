---
name: write-pr-report
description: Generate a concise, reviewer-friendly pull request description from current repository changes.
---

# Write PR Report

## Purpose

Turn completed work into a short PR description that explains what changed, why it matters, and how it was validated.

## Use When

- the implementation is complete
- a reviewer needs a clean summary

## Workflow

1. Inspect current changes.
2. Group changes by responsibility.
3. Write a compact report with summary, grouped changes, validation, reviewer notes, and real risks.

## Guardrails

- avoid planning artifacts
- avoid internal implementation noise
- do not invent validation evidence
