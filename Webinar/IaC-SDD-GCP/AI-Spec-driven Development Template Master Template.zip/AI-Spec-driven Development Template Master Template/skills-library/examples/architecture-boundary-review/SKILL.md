---
name: architecture-boundary-review
description: Review a codebase or change set for ownership clarity, dependency direction, and contract-safe boundaries.
---

# Architecture Boundary Review

## Purpose

Catch architectural drift before it hardens into implementation.

## Workflow

1. Identify owning modules and layers.
2. Check allowed and forbidden dependencies.
3. Check contract truth at boundaries.
4. Report violations and missing tests.

## Guardrails

- prioritize real boundary risks over style issues
- tie findings to concrete modules or files
