---
name: ux-state-audit
description: Audit whether a product surface exposes explicit loading, empty, degraded, error, and streaming states with clear user feedback.
---

# UX State Audit

## Purpose

Find gaps in user-visible state handling before they become trust problems.

## Workflow

1. Identify the main user flows.
2. Map explicit states and transitions.
3. Flag hidden, ambiguous, or missing states.
4. Recommend concrete state improvements.

## Guardrails

- focus on behavior, not decorative styling
- include degraded and failure states, not only happy paths
