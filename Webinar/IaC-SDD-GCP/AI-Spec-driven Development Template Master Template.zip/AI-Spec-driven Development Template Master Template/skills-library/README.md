# Skills Library

This folder contains reusable guidance for packaging agent skills in a disciplined, portable way.

## Contents

- [skill-packaging-guide.md](skill-packaging-guide.md)
- [skill-template/SKILL.md](skill-template/SKILL.md)
- [skill-template/agents-openai-yaml-template.md](skill-template/agents-openai-yaml-template.md)
- [skill-template/reference-layout.md](skill-template/reference-layout.md)
- `examples/`: concrete reusable skills

## Design Rules

- keep `SKILL.md` concise
- put durable detail in optional references
- use one shared skill source, then expose tool-specific adapters if needed
- do not turn skills into giant documentation bundles
