# Skill Packaging Guide

## Purpose

Define how to create reusable skills without polluting the context window or duplicating tool-specific content.

## Minimal Skill Shape

```text
{{skill_name}}/
├── SKILL.md
├── agents/
│   └── openai.yaml
├── references/
└── scripts/
```

## Packaging Rules

- `SKILL.md` should state purpose, triggers, workflow, and guardrails only.
- Long explanations belong in `references/`.
- Deterministic repeatable logic belongs in `scripts/`.
- UI metadata should be generated from the shared skill, not authored as a separate worldview.

## Skill Quality Tests

- could another agent understand when to use it
- does it avoid repo-specific leakage unless intentional
- does it minimize context use
- does it define outputs and failure handling clearly
