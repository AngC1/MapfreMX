# agents/openai.yaml Template

```yaml
display_name: {{skill_display_name}}
short_description: {{short_description}}
default_prompt: {{default_prompt}}
```

## Rules

- derive this metadata from the shared skill
- keep names human-readable
- avoid restating the full skill body
