---
name: {{skill_name}}
description: {{one_to_two_sentence_trigger_description}}
---

# {{skill_display_name}}

## Purpose

{{skill_purpose}}

## Use When

- {{trigger_1}}
- {{trigger_2}}

## Do Not Use When

- {{anti_trigger_1}}
- {{anti_trigger_2}}

## Workflow

1. {{step_1}}
2. {{step_2}}
3. {{step_3}}

## Required Outputs

- {{output_1}}
- {{output_2}}

## Guardrails

- {{guardrail_1}}
- {{guardrail_2}}

## Optional References

- `references/{{reference_file}}`: {{when_to_read_it}}
