# Skill Reference Layout

Use optional reference files only when they materially improve execution.

## Recommended Layout

```text
references/
├── workflows.md
├── schemas.md
├── examples.md
└── policies.md
```

## Rules

- link every reference directly from `SKILL.md`
- keep references one level deep
- split by domain or variant when the skill supports multiple modes
