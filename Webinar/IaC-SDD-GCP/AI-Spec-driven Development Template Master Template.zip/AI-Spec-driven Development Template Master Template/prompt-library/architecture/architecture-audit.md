# Prompt: Architecture Audit

## Purpose

Evaluate whether the repository's current implementation and docs still match its intended architecture.

## Trigger

Use when boundaries feel blurred, docs may have drifted, or new modules are being introduced.

## Required Inputs

- constitution
- ADR index and relevant ADRs
- contracts
- module specs
- representative code paths

## Output Contract

- useful assets
- incomplete areas
- redundant documents or flows
- improvement recommendations

## Guardrails

- distinguish doc problems from code problems
- tie findings to concrete files
- note open questions separately from defects

## Failure Modes

- audit restates docs without evaluating real usage
- findings lack file evidence
- every difference is treated as a defect instead of a scope mismatch
