# Prompt: PR Report Writing

## Purpose

Generate a reviewer-friendly summary of a completed change.

## Trigger

Use after implementation and validation are done.

## Required Inputs

- git diff or changed-file summary
- validation results
- scope of the completed task

## Output Contract

- short title
- compact summary
- grouped changes
- validation note
- real risks only

## Guardrails

- avoid implementation noise
- do not include planning artifacts
- keep the report useful to a reviewer, not to a future historian

## Failure Modes

- summary is too long
- risks are speculative instead of real
- validation claims exceed actual evidence
