# Prompt: Smallest Unlocked Task Execution

## Purpose

Drive one safe implementation pass against the next actionable task.

## Trigger

Use when the repository already has clear backlog and progress files.

## Required Inputs

- `{{agent_brief_file}}`
- `{{backlog_file}}`
- `{{progress_file}}`
- `{{validation_command_or_rule}}`

## Output Contract

- one completed task or one clearly blocked task
- compact execution summary
- updated operational files if status changed

## Guardrails

- process exactly one smallest unlocked task
- avoid unrelated edits
- keep validation bounded to the changed area

## Failure Modes

- backlog too vague to identify one task
- operational files drift from actual code
- loop broadens scope across multiple tasks
