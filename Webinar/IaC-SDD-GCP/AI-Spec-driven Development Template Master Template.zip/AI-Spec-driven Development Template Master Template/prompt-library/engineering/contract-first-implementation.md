# Prompt: Contract-First Implementation

## Purpose

Force implementation work to start from public contracts, errors, and boundary rules instead of ad hoc code paths.

## Trigger

Use when a task touches a public interface, API, event, DTO, or cross-module boundary.

## Required Inputs

- relevant contract docs
- module spec or ADR
- current implementation entrypoints

## Output Contract

- boundary impact summary
- implementation aligned to existing contracts or explicit contract updates
- tests for affected contracts

## Guardrails

- do not widen payloads silently
- normalize errors before they cross boundaries
- update docs when contract behavior changes

## Failure Modes

- implementation starts from storage or UI details
- contracts remain outdated after code changes
- boundary changes ship without fixture coverage
