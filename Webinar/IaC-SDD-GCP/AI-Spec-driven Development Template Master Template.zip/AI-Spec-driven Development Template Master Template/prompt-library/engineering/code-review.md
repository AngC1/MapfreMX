# Prompt: Code Review

## Purpose

Review changes for bugs, regressions, boundary violations, and missing tests.

## Trigger

Use when the user asks for a review or when high-risk changes land across module boundaries.

## Required Inputs

- diff or changed files
- relevant canonical docs
- test evidence if available

## Output Contract

- findings first, ordered by severity
- file references for each finding
- open questions or assumptions
- brief summary only after findings

## Guardrails

- prioritize correctness and boundary safety over style
- do not bury real defects under long summaries

## Failure Modes

- review becomes a changelog
- style nits displace real behavior risks
- missing tests are not called out
