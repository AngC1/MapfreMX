# Prompt: Documentation Reconciliation

## Purpose

Reconcile overlapping docs into a clear source-of-truth hierarchy.

## Trigger

Use when multiple docs talk about the same system behavior, scope, or workflow.

## Required Inputs

- candidate overlapping docs
- known contradictions
- current repository structure

## Output Contract

- inventory of relevant docs
- conflict list
- normalized hierarchy
- update recommendations

## Guardrails

- preserve provenance without treating source snapshots as implementation-safe
- keep specialized docs scoped instead of deleting them automatically

## Failure Modes

- reconciliation destroys useful provenance
- hierarchy remains ambiguous
- specialized docs are allowed to overrule cross-cutting policy by accident
