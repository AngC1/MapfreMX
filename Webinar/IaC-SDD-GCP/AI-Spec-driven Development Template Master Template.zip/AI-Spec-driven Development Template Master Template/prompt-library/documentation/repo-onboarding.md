# Prompt: Repo Onboarding

## Purpose

Create a fast, trustworthy onboarding path for a new human or agent entering the repository.

## Trigger

Use when a repo has good docs but weak first-contact guidance.

## Required Inputs

- README
- canonical doc hierarchy
- current test commands
- operational state files

## Output Contract

- recommended read order
- short repo mental model
- safe first commands
- common mistakes and escalation path

## Guardrails

- optimize for fast comprehension
- keep the onboarding path short
- do not duplicate deep architecture content

## Failure Modes

- onboarding doc becomes a full architecture mirror
- critical commands are omitted
- canonical vs operational split is unclear
