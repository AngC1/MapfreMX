# Prompt: Accessibility and Product Critique

## Purpose

Critique a product surface for accessibility, keyboard behavior, feedback clarity, and user trust.

## Trigger

Use when reviewing UX quality beyond pure layout.

## Required Inputs

- screen descriptions or mockups
- interaction model
- accessibility or product-quality rules if available

## Output Contract

- prioritized findings
- rationale tied to user impact
- concrete improvements

## Guardrails

- focus on behavior and usability, not taste
- call out invisible states, focus traps, weak affordances, and unreadable feedback

## Failure Modes

- review becomes generic design commentary
- accessibility is reduced to color contrast only
- no prioritization by severity
