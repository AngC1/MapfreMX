# Prompt: UX State Audit

## Purpose

Audit whether a product surface exposes explicit, coherent user-visible states.

## Trigger

Use when a UI exists or is being designed and state clarity matters.

## Required Inputs

- relevant UI specs or ADRs
- key screens or view models
- state-related error and degraded behavior docs

## Output Contract

- identified states
- missing states
- ambiguous transitions
- recommendations for empty, loading, degraded, error, and streaming behavior

## Guardrails

- separate product state from visual styling
- require explicit degraded and failure states

## Failure Modes

- audit focuses only on visual polish
- hidden loading or degraded behavior is ignored
- state recommendations invent new business rules
