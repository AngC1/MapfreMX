# Canonical vs Operational Documents

## Canonical Documents

Canonical documents define durable truth. They are used to decide behavior, boundaries, and correctness.

Typical canonical documents:
- constitution
- cross-cutting ADRs
- contracts
- module specs
- reliability docs
- performance budgets
- eval strategy

Canonical docs should answer:
- what the system is
- what each module owns
- what crosses boundaries
- what happens when things fail
- what evidence is required before work is accepted

## Operational Documents

Operational documents coordinate current execution. They should be short, current, and disposable.

Typical operational documents:
- `backlog.md`
- `progress.md`
- task briefs
- session handoffs
- validation reports
- daily decision logs

Operational docs should answer:
- what is active now
- what changed recently
- what is blocked
- what the next safe task is

## Hard Rule

Operational docs never redefine canonical behavior. If execution reveals a mismatch, update canonical docs intentionally or record an explicit assumption.

## Practical Test

Ask:
- "Would this still be true after the current sprint?" If yes, it is probably canonical.
- "Is this only about the current working state?" If yes, it is operational.
