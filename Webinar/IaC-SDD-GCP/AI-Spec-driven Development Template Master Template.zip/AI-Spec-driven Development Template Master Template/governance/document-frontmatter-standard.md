# Document Frontmatter Standard

All canonical templates in this framework use the same metadata block.

```yaml
---
status: {{doc_status}}
doc-type: {{doc_type}}
authority: {{canonical_or_operational}}
scope: {{doc_scope}}
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---
```

## Field Meanings

- `status`: draft, proposed, accepted, deprecated, superseded
- `doc-type`: constitution, adr, contract, spec, quality-policy, review, other
- `authority`: canonical or operational
- `scope`: repository-wide, module, feature, workflow, team, other bounded scope
- `owner`: team or role accountable for keeping the doc current
- `last-updated`: ISO date
- `supersedes`: prior document replaced by this one
- `superseded-by`: later document that replaced this one

## Rules

- Use frontmatter for canonical docs by default.
- Use it for operational docs only if the repo values metadata search strongly.
- Do not invent new fields casually. Extend only when the whole repo benefits.
