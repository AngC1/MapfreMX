---
status: {{doc_status}}
doc-type: governance
authority: canonical
scope: repository-wide
owner: {{doc_owner}}
last-updated: {{yyyy-mm-dd}}
supersedes: {{document_path_or_none}}
superseded-by: {{document_path_or_none}}
---

# Document Hierarchy and Precedence

## Purpose

Define which documents win when two sources appear to conflict.

## Recommended Hierarchy

1. Constitution or equivalent engineering law
2. Cross-cutting ADRs
3. Module ownership specs
4. Contracts at boundaries
5. Reliability and performance policies
6. Eval strategy
7. Planning documents
8. Operational execution files
9. Preserved source snapshots and research notes

## Boundary Rule

At module boundaries, contract docs win over narrative specs.

## Interpretation Rule

If two canonical docs conflict:
- the narrower document wins only inside its explicit scope
- the broader document wins on cross-cutting concerns
- if the conflict is real and unresolved, record it and stop guessing

## Operational Rule

Operational docs are execution aids. They never outrank canonical docs.
