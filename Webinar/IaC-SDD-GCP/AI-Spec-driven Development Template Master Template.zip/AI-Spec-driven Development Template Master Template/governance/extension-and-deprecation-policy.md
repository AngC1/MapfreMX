# Extension and Deprecation Policy

This framework is meant to grow carefully, not continuously.

## When To Add A New Document Type

Add a new document type only when:
- an existing type cannot carry the required decision safely
- the distinction will remain useful over time
- multiple teams or agents will benefit from the new type

## When To Extend An Existing Template

Prefer extension when:
- the new need fits an existing document's purpose
- a new section solves the problem
- the change reduces ambiguity without adding a parallel artifact

## Deprecation Rules

- Mark deprecated docs explicitly.
- Point to the replacement doc.
- Keep the deprecated doc only long enough to preserve traceability.
- Remove or archive dead duplicates instead of letting them compete forever.

## Change Hygiene

Whenever a canonical template changes:
- update the framework map if needed
- update related prompts or skills if their assumptions changed
- check whether the examples still match the rule
