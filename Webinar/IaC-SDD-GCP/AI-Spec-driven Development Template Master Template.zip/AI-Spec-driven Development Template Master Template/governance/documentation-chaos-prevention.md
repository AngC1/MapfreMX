# Documentation Chaos Prevention

Documentation chaos usually comes from good intentions plus weak authority boundaries.

## Anti-Chaos Rules

- One purpose per document.
- One source of truth per policy.
- One shared rule set per agent ecosystem, then thin tool adapters.
- Canonical docs stay durable. Operational docs stay compact.
- Generated artifacts are never treated as documentation.
- If a file exists only because "someone might want it later," delete it.

## Common Failure Patterns

- roadmap docs that become live task trackers
- ADRs that restate contracts instead of decisions
- handoff docs that drift into pseudo-architecture
- multiple tool-specific rule files that silently diverge
- example docs that get mistaken for standards

## Prevention Checks

Before adding or keeping a doc, ask:
- what unique question does it answer
- who depends on it
- what higher-authority doc it depends on
- how it will be kept current

If those answers are weak, do not add the doc.
