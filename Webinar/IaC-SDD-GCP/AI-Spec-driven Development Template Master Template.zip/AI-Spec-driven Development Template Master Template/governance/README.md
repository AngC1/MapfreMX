# Governance Library

This folder defines how the documentation system stays coherent as a repository grows.

Use these documents to answer four questions:
- what is canonical
- what is operational
- which document wins in a conflict
- how the repo extends the system without turning every idea into a new doc type

## Files

- [canonical-vs-operational.md](canonical-vs-operational.md): authority split
- [document-frontmatter-standard.md](document-frontmatter-standard.md): frontmatter fields for canonical templates
- [document-hierarchy-and-precedence-template.md](document-hierarchy-and-precedence-template.md): conflict-resolution model
- [extension-and-deprecation-policy.md](extension-and-deprecation-policy.md): how docs evolve
- [documentation-chaos-prevention.md](documentation-chaos-prevention.md): guardrails against duplication and drift

## Governance Rule

Do not create more document types until the existing ones fail clearly. Proliferation is the fastest path to documentation ambiguity.
